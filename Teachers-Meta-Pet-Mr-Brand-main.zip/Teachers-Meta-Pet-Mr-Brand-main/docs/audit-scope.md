# Audit Scope

## Canonical product identity
- **Repository name:** `teachers-meta-pet-mr-brand`
- **Application name:** `veil-hub`
- **Purpose:** Next.js app for mentor/pet experiences, including pairing, care flows, blessing forge, constellation, and legal disclosure pages.

### Declared app names
- `veil-hub`
- `teachers-meta-pet-mr-brand`

### Declared product hosts
- `localhost:3000`

## Top-level route map
- `/` — landing/dashboard
- `/pair` — pairing flow
- `/pet` — pet status and care view
- `/forge` — blessing forge
- `/constellation` — constellation view
- `/legal` — legal notice and terms
- Framework routes: loading and not-found UI are implemented in the app shell.

## Major modules in this repo
- `veil-hub/src/app` — route entrypoints and app shell
- `veil-hub/src/components/veil` — domain-specific Veil UI modules
- `veil-hub/src/components/mentor` — mentor dashboard components
- `veil-hub/src/components/ui` — shared primitive UI components
- `veil-hub/src/lib/veil` — domain logic/helpers for pairing, blessings, capsules, mentor-pet state

## Not in this repo
- Mini-games and standalone kid-game loops are out of scope for this repository audit.
- Genome simulator features are out of scope for this repository audit.
- Pet-feeding gameplay UX implementations are out of scope for this repository audit.
- If an audit report mentions these areas, reviewers must mark them as **external evidence** and avoid treating them as in-repo findings.

## Excluded systems (not present here)
- No backend API service or server-side microservice repository
- No mobile app codebase (iOS/Android)
- No database schema/migrations directory
- No unrelated products (for example: LMS portals, ecommerce storefronts, CRM apps)
