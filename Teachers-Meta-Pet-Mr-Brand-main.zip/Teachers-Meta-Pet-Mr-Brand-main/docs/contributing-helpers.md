# Contributing Helpers

To avoid drifting copies of shared helpers, keep canonical implementations in one file and import from there.

## Canonical helper locations

- `getISOWeek()` → `veil-hub/src/lib/veil/helpers.ts`
- `createPlaceholderSignature()` → `veil-hub/src/lib/veil/helpers.ts`

## How to add or update shared helpers

1. Implement or edit the helper in `veil-hub/src/lib/veil/helpers.ts`.
2. Update calling modules to import from `./helpers` instead of defining local copies.
3. Run the duplicate signature check:

```bash
cd veil-hub
npm run lint:helpers
```

The check fails if `getISOWeek` or `createPlaceholderSignature` is redeclared outside their canonical file.
