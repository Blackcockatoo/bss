# Audit Report Checklist

Use this checklist before finalizing any `docs/audit-report*.md` file.

- [ ] Every claim is mapped to a concrete route or module under `veil-hub/src/app`.
- [ ] Every mapped claim includes route/module evidence (for example, matching file paths in `veil-hub/src/app/**`).
- [ ] Any mention of out-of-scope kid-game features (mini-games, genome simulator, pet-feeding UX) is flagged as **external evidence**.
- [ ] Product/app names and product hosts referenced in the report are declared in `docs/audit-scope.md`.
- [ ] No denylisted product identifiers are present (run `npm run lint:audit`).
