# Teachers Meta Pet Mr Brand

## Repository Identity
This repository contains **Veil Hub** (`veil-hub`), a Next.js application for mentor/pet interactions: pairing, caring for a pet, forging blessings, viewing constellation state, and exposing legal notice content. If your audit references other product names, unrelated routes, or systems outside this frontend app, you are likely reviewing the wrong codebase.

## Maintenance
Run a full maintenance update (audit docs + helper lint + test suite + production build):

```bash
npm run update:full
```

## Deployment
Prepare the app for deployment by running:

```bash
npm run deploy:prep
```

Then deploy with your hosting provider (the repository includes `vercel.json` for Vercel deployments).

