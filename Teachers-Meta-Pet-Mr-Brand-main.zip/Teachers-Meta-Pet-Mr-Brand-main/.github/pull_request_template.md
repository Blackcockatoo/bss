## Summary
- Describe the change and why it is needed.

## Validation
- [ ] I ran relevant local checks/tests.

## Audit alignment checklist
- [ ] I confirmed the app name and purpose align with this repository.
- [ ] I confirmed the top-level route inventory is accurate for this repository.
- [ ] I confirmed key directories/modules listed are present in this repository.
