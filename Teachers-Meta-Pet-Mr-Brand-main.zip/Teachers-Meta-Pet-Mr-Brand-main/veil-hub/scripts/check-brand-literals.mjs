import { promises as fs } from 'node:fs';
import path from 'node:path';

const SOURCE_ROOT = path.resolve(process.cwd(), 'src');
const ALLOWED_FILES = new Set([path.resolve(SOURCE_ROOT, 'lib/brand.ts')]);
const DISALLOWED_BRAND_LITERALS = ['Jewble', 'Blue Snake Studios', 'The Veil', 'Blackcockatoo'];
const SOURCE_EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);

async function collectSourceFiles(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      files.push(...await collectSourceFiles(fullPath));
      continue;
    }

    if (entry.isFile() && SOURCE_EXTENSIONS.has(path.extname(entry.name))) {
      files.push(fullPath);
    }
  }

  return files;
}

function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, match => ' '.repeat(match.length))
    .replace(/(^|[^:])\/\/.*$/gm, (match, prefix) => `${prefix}${' '.repeat(match.length - prefix.length)}`);
}

function getLineColumn(source, index) {
  const upToIndex = source.slice(0, index);
  const lines = upToIndex.split('\n');
  return { line: lines.length, column: lines.at(-1).length + 1 };
}

function findDisallowedLiterals(source) {
  const cleanSource = stripComments(source);
  const literalRegex = /(['"`])(?:\\.|(?!\1)[\s\S])*?\1/g;
  const violations = [];

  let match;
  while ((match = literalRegex.exec(cleanSource)) !== null) {
    const literal = match[0].slice(1, -1);

    for (const blockedTerm of DISALLOWED_BRAND_LITERALS) {
      if (!literal.includes(blockedTerm)) {
        continue;
      }

      const { line, column } = getLineColumn(cleanSource, match.index + 1);
      violations.push({ blockedTerm, line, column });
    }
  }

  return violations;
}

async function main() {
  const files = await collectSourceFiles(SOURCE_ROOT);
  const violations = [];

  for (const filePath of files) {
    if (ALLOWED_FILES.has(filePath)) {
      continue;
    }

    const source = await fs.readFile(filePath, 'utf8');
    const fileViolations = findDisallowedLiterals(source);

    for (const violation of fileViolations) {
      violations.push({ filePath, ...violation });
    }
  }

  if (violations.length === 0) {
    console.log('✅ Brand literal check passed.');
    return;
  }

  console.error('❌ Non-approved brand literals found:');
  for (const violation of violations) {
    const relPath = path.relative(process.cwd(), violation.filePath);
    console.error(`- ${relPath}:${violation.line}:${violation.column} => ${violation.blockedTerm}`);
  }

  process.exitCode = 1;
}

main().catch(error => {
  console.error('❌ Brand literal check failed to run.');
  console.error(error);
  process.exit(1);
});
