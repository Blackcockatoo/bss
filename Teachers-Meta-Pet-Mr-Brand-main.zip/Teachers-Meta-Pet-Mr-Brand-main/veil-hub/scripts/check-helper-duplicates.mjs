import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const rootDir = new URL('../', import.meta.url);
const veilDir = join(rootDir.pathname, 'src', 'lib', 'veil');

const canonicalHelpers = {
  getISOWeek: 'src/lib/veil/helpers.ts',
  createPlaceholderSignature: 'src/lib/veil/helpers.ts',
};

function listFiles(dir) {
  const entries = readdirSync(dir);
  return entries.flatMap((entry) => {
    const absolutePath = join(dir, entry);
    const stats = statSync(absolutePath);

    if (stats.isDirectory()) {
      return listFiles(absolutePath);
    }

    if (absolutePath.endsWith('.ts') || absolutePath.endsWith('.tsx')) {
      return [absolutePath];
    }

    return [];
  });
}

const files = listFiles(veilDir);
const duplicateErrors = [];

for (const [helperName, canonicalPath] of Object.entries(canonicalHelpers)) {
  const regex = new RegExp(
    `^\\s*(?:export\\s+)?(?:async\\s+)?function\\s+${helperName}\\s*\\(`,
    'gm',
  );

  const declarations = files
    .filter((filePath) => readFileSync(filePath, 'utf8').match(regex))
    .map((filePath) => relative(rootDir.pathname, filePath));

  const invalidDeclarations = declarations.filter((path) => path !== canonicalPath);

  if (invalidDeclarations.length > 0) {
    duplicateErrors.push(
      [
        `Found non-canonical declaration(s) for ${helperName}:`,
        ...invalidDeclarations.map((path) => `  - ${path}`),
        `Canonical location: ${canonicalPath}`,
      ].join('\n'),
    );
  }
}

if (duplicateErrors.length > 0) {
  console.error('Duplicate helper signature check failed.\n');
  console.error(duplicateErrors.join('\n\n'));
  process.exit(1);
}

console.log('Helper duplicate check passed.');
