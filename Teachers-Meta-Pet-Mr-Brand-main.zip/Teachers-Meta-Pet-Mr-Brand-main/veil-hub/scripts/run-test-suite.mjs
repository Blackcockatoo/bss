#!/usr/bin/env node

import { rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

function runStep(name, cmd, args) {
  console.log(`\n[Test Suite] ${name}`);
  const result = spawnSync(cmd, args, { stdio: 'inherit', shell: false });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

rmSync('.tmp-test', { recursive: true, force: true });

try {
  runStep('Compile TypeScript tests', 'npm', ['exec', '--', 'tsc', '-p', 'test/tsconfig.test.json']);
  runStep('Run compiled test harness', process.execPath, ['.tmp-test/test/run-tests.js']);
} finally {
  rmSync('.tmp-test', { recursive: true, force: true });
}
