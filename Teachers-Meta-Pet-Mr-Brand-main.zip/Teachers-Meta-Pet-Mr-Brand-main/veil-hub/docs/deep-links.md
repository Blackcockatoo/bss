# Veil Flow Route Map & Deep Links

This repo now exposes **teacher routes** and **kid routes** as separate segments.

## Role separation

- Teacher segment: `/`, `/pair`, `/forge`, `/dna-hub`, `/digital-dna`, `/school-quest`, `/constellation`, `/pet`
- Kid segment: `/kid`, `/kid/pair`, `/kid/redeem`, `/kid/bonds`
- Route guards are handled client-side via `RoleGuard` and the `veil-role` key in `localStorage`.
- Role switch links:
  - `/?as=teacher`
  - `/kid?as=kid`

## Kid component inventory mapped to routes

| Component | Route | Purpose |
| --- | --- | --- |
| `PairConfirm` | `/kid/pair?invite=<serializedInvite>&crest=<petCrestHash>` | Kid consent/acceptance for teacher pairing invite. |
| `RedeemBlessing` | `/kid/redeem` | Kid enters signed blessing payload and redeems unlocks. |
| `BondMarks` | `/kid/bonds` | Kid reviews and releases active mentor bonds. |

## End-to-end smoke walkthrough

1. Open teacher hub at `/`.
2. Go to `/pair` and generate an invite.
3. Copy invite JSON and open `/kid/pair?invite=<...>&crest=my-pet&as=kid`.
4. Accept bond and copy response code.
5. Return to teacher `/pair?as=teacher` and paste response to complete bond.
6. Forge a blessing at `/forge` and copy full blessing data.
7. Open `/kid/redeem` and redeem the blessing data.
8. Open `/kid/bonds` to verify mentor bond visibility and controls.
