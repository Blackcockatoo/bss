import { test, assert } from './harness';
import { resetStorage } from './env';
import { createVault, deleteVault } from '../src/lib/veil/vault';
import { initializeMentorPet, clearMentorPet } from '../src/lib/veil/mentor-pet';
import { addBondMark, clearBondMarks } from '../src/lib/veil/pairing';
import {
  clearRedeemedBlessings,
  forgeBlessing,
  isBlessingRedeemed,
  redeemBlessing,
  verifyBlessingObject,
} from '../src/lib/veil/blessing';

async function prep(): Promise<void> {
  resetStorage();
  deleteVault();
  clearMentorPet();
  clearBondMarks();
  clearRedeemedBlessings();
  await createVault();
  initializeMentorPet();
}

test('blessing forge + verify succeeds', async () => {
  await prep();

  const blessing = await forgeBlessing('sticker', { name: 'Gold Star' });
  assert.ok(blessing);

  const verification = await verifyBlessingObject(blessing!);
  assert.equal(verification.valid, true);
});

test('blessing verify fails when payload is tampered', async () => {
  await prep();

  const blessing = await forgeBlessing('aura', { name: 'Calm Light' });
  const tampered = { ...blessing!, metadata: { name: 'Hacked' } };

  const verification = await verifyBlessingObject(tampered);
  assert.equal(verification.valid, false);
  assert.match(verification.error ?? '', /Invalid blessing signature/);
});

test('blessing redeem allows first and blocks duplicate', async () => {
  await prep();

  const blessing = await forgeBlessing('accessory', { name: 'Mentor Pin' });
  assert.ok(blessing);

  addBondMark(
    {
      type: 'veil-pair-invite',
      hubId: 'HUB-TEST1234',
      teacherPubKey: blessing!.issuedBy,
      expiresAt: Date.now() + 1000,
      signature: 'signature-not-used-here',
    },
    ['receiveBlessings']
  );

  const first = await redeemBlessing(blessing!);
  const second = await redeemBlessing(blessing!);

  assert.equal(first.success, true);
  assert.equal(first.redemption?.mentorHubId, 'HUB-TEST1234');
  assert.equal(isBlessingRedeemed(blessing!.blessingId), true);
  assert.equal(second.success, false);
  assert.match(second.error ?? '', /already been redeemed/);
});
