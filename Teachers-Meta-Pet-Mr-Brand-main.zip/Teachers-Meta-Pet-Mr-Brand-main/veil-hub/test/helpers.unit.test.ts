import { test, assert } from './harness';
import { getISOWeek } from '../src/lib/veil/helpers';

test('ISO helper returns year-boundary week', () => {
  assert.equal(getISOWeek(new Date('2021-01-01T00:00:00.000Z')), '2020-W53');
});

test('ISO helper returns expected mid-year week', () => {
  assert.equal(getISOWeek(new Date('2026-02-06T00:00:00.000Z')), '2026-W06');
});

test('ISO helper pads single-digit weeks', () => {
  assert.equal(getISOWeek(new Date('2026-01-05T00:00:00.000Z')), '2026-W02');
});
