import './env';
import './vault.unit.test';
import './blessing.unit.test';
import './helpers.unit.test';
import './flows.integration.test';
import { run } from './harness';

run();
