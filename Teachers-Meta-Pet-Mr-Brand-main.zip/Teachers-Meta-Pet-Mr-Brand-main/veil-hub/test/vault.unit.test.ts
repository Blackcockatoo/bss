import { test, assert } from './harness';
import { resetStorage } from './env';
import { createVault, deleteVault, getVault, signData, unlockVault, verifySignature } from '../src/lib/veil/vault';

test('vault creates passcode-protected keys and verifies signatures', async () => {
  resetStorage();
  deleteVault();

  const vault = await createVault('1234');
  assert.ok(vault.publicKey);
  assert.match(vault.hubId, /^hub-/);

  const payload = JSON.stringify({ kind: 'mentor-message' });
  const signature = await signData(payload, '1234');
  assert.ok(signature.length > 0);

  assert.equal(await verifySignature(payload, signature, vault.publicKey), true);
  assert.equal(await verifySignature(`${payload}-tampered`, signature, vault.publicKey), false);
});

test('vault unlock rejects incorrect passcode', async () => {
  resetStorage();
  deleteVault();

  await createVault('9999');

  assert.equal(await unlockVault('bad'), false);
  assert.equal(await unlockVault('9999'), true);
  assert.ok(getVault());
});
