class MemoryStorage {
  private store = new Map<string, string>();

  getItem(key: string): string | null {
    return this.store.has(key) ? this.store.get(key)! : null;
  }

  setItem(key: string, value: string): void {
    this.store.set(key, value);
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }
}

const localStorage = new MemoryStorage();

(globalThis as any).window = globalThis;
(globalThis as any).localStorage = localStorage;

if (!(globalThis as any).btoa) {
  (globalThis as any).btoa = (input: string) => Buffer.from(input, 'binary').toString('base64');
}

if (!(globalThis as any).atob) {
  (globalThis as any).atob = (input: string) => Buffer.from(input, 'base64').toString('binary');
}

export function resetStorage(): void {
  localStorage.clear();
}
