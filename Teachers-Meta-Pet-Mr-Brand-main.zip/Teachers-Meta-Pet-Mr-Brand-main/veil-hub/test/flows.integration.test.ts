import { test, assert } from './harness';
import { resetStorage } from './env';
import { createVault, deleteVault, getVault } from '../src/lib/veil/vault';
import { clearMentorPet, getGrowthInfo, getMentorPet, initializeMentorPet } from '../src/lib/veil/mentor-pet';
import {
  addBondMark,
  clearBondMarks,
  createPairingInvite,
  createPairingResponse,
  processPairingResponse,
  verifyPairingInvite,
} from '../src/lib/veil/pairing';
import {
  clearRedeemedBlessings,
  forgeBlessing,
  processRedemptionConfirmation,
  redeemBlessing,
} from '../src/lib/veil/blessing';

async function boot(): Promise<void> {
  resetStorage();
  deleteVault();
  clearMentorPet();
  clearBondMarks();
  clearRedeemedBlessings();
  await createVault();
  initializeMentorPet();
}

test('integration: pairing invite/accept flow', async () => {
  await boot();

  const invite = await createPairingInvite();
  assert.ok(invite);
  const verification = await verifyPairingInvite(invite!);
  assert.equal(verification.valid, true);

  addBondMark(invite!, ['receiveBlessings', 'viewWellbeing']);
  const response = await createPairingResponse('kid-crest-001', ['receiveBlessings'], 'Nova');

  const processed = await processPairingResponse(response);
  assert.equal(processed.success, true);
  assert.equal(getMentorPet()?.constellation.length, 1);
  assert.equal(getMentorPet()?.constellation[0].alias, 'Nova');
});

test('integration: blessing redemption flow', async () => {
  await boot();

  const invite = await createPairingInvite();
  addBondMark(invite!, ['receiveBlessings']);

  const blessing = await forgeBlessing('sticker', { name: 'Flow Sticker' });
  const redeemed = await redeemBlessing(blessing!);

  assert.equal(redeemed.success, true);
  assert.equal(redeemed.redemption?.mentorHubId, invite!.hubId);
});

test('integration: mentor pet XP/tier progression', async () => {
  await boot();

  const invite = await createPairingInvite();
  addBondMark(invite!, ['receiveBlessings']);

  for (let i = 0; i < 4; i++) {
    const response = await createPairingResponse(`kid-crest-${i}`, ['receiveBlessings']);
    await processPairingResponse(response);
  }

  for (let i = 0; i < 3; i++) {
    const blessing = await forgeBlessing('aura', { name: `Aura ${i}` });
    await redeemBlessing(blessing!);
    processRedemptionConfirmation(blessing!.blessingId);
  }

  const growth = getGrowthInfo();
  assert.ok(growth);
  assert.ok(growth!.xp >= 61);
  assert.ok(growth!.tier >= 1);
  assert.match(getVault()!.hubId, /^hub-/);
});
