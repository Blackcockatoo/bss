'use client';

import { useEffect, useState } from 'react';

type VeilRole = 'teacher' | 'kid';

interface RoleGuardProps {
  requiredRole: VeilRole;
  redirectTo: string;
  children: React.ReactNode;
}

function getRoleFromQuery(): VeilRole | null {
  const params = new URLSearchParams(window.location.search);
  const role = params.get('as');
  return role === 'teacher' || role === 'kid' ? role : null;
}

export function RoleGuard({ requiredRole, redirectTo, children }: RoleGuardProps) {
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    const queryRole = getRoleFromQuery();
    if (queryRole) {
      localStorage.setItem('veil-role', queryRole);
    }

    const currentRole = (localStorage.getItem('veil-role') as VeilRole | null) ?? requiredRole;

    if (!localStorage.getItem('veil-role')) {
      localStorage.setItem('veil-role', requiredRole);
    }

    if (currentRole !== requiredRole) {
      window.location.replace(redirectTo);
      return;
    }

    setAllowed(true);
  }, [requiredRole, redirectTo]);

  if (!allowed) {
    return (
      <div className="flex min-h-[30vh] items-center justify-center text-sm text-slate-400">
        Checking access...
      </div>
    );
  }

  return <>{children}</>;
}
