'use client';

import React, { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    THREE?: any;
    Tone?: any;
  }
}

const THREE_CDN = 'https://unpkg.com/three@0.180.0/build/three.min.js';
const TONE_CDN = 'https://unpkg.com/tone@15.1.22/build/Tone.js';

const loadScript = (src: string): Promise<void> => {
  if (typeof window === 'undefined') {
    return Promise.resolve();
  }

  const existing = document.querySelector(`script[src="${src}"]`) as HTMLScriptElement | null;
  if (existing) {
    if (existing.dataset.loaded === 'true') {
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error(`Failed to load ${src}`)), { once: true });
    });
  }

  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.dataset.loaded = 'false';
    script.onload = () => {
      script.dataset.loaded = 'true';
      resolve();
    };
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });
};

const DigitalDNAHub = () => {
  const SEEDS = {
    red: '113031491493585389543778774590997079619617525721567332336510',
    black: '011235831459437077415617853819099875279651673033695493257291',
    blue: '012776329785893036118967145479098334781325217074992143965631'
  };

  const [activeMode, setActiveMode] = useState<'spiral' | 'mandala' | 'sound' | 'particles' | 'journey'>('spiral');
  const [selectedSeed, setSelectedSeed] = useState<'red' | 'black' | 'blue'>('red');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioInitialized, setAudioInitialized] = useState(false);
  const [consciousness, setConsciousness] = useState(50);
  const [harmony, setHarmony] = useState(7);
  const [tempo, setTempo] = useState(120);
  const [paintedPattern, setPaintedPattern] = useState<Array<{ x: number; y: number }>>([]);
  const [librariesReady, setLibrariesReady] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const synthRef = useRef<any>(null);
  const particlesRef = useRef<any[]>([]);
  const mouseRef = useRef({ x: 0, y: 0, down: false });

  const digitToNote = (digit: number) => ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5', 'D5', 'E5'][digit];
  const digitToColor = (digit: number) => [
    '#1a1a2e', '#16213e', '#0f3460', '#533483', '#8b5cf6',
    '#ffd700', '#ff6b6b', '#4ecdc4', '#95e1d3', '#f38181'
  ][digit];
  const getSequence = () => SEEDS[selectedSeed].split('').map(Number);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await Promise.all([loadScript(THREE_CDN), loadScript(TONE_CDN)]);
        if (mounted && window.THREE && window.Tone) {
          setLibrariesReady(true);
        }
      } catch {
        setLibrariesReady(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!librariesReady || synthRef.current) return;
    const Tone = window.Tone;
    synthRef.current = new Tone.PolySynth(Tone.Synth, {
      oscillator: { type: 'sine' },
      envelope: { attack: 0.1, decay: 0.2, sustain: 0.3, release: 1 }
    }).toDestination();

    const reverb = new Tone.Reverb({ decay: 4, wet: 0.3 }).toDestination();
    synthRef.current.connect(reverb);
  }, [librariesReady]);

  const playSequence = async () => {
    if (!librariesReady || !window.Tone || !synthRef.current) return;
    const Tone = window.Tone;
    if (!audioInitialized) {
      await Tone.start();
      setAudioInitialized(true);
    }

    setIsPlaying(true);
    const sequence = getSequence();
    const now = Tone.now();
    const interval = 60 / tempo;

    sequence.slice(0, 60).forEach((digit, i) => {
      synthRef.current.triggerAttackRelease(digitToNote(digit), interval * 0.8, now + i * interval);
    });

    setTimeout(() => setIsPlaying(false), sequence.slice(0, 60).length * interval * 1000);
  };

  const playChord = (digits: number[]) => {
    if (!audioInitialized || !synthRef.current) return;
    synthRef.current.triggerAttackRelease(digits.map(digitToNote), '4n');
  };

  useEffect(() => {
    if (!librariesReady || !canvasRef.current || activeMode !== 'spiral') return;
    const THREE = window.THREE;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0e27);

    const camera = new THREE.PerspectiveCamera(75, 800 / 600, 0.1, 1000);
    camera.position.z = 20;

    const renderer = new THREE.WebGLRenderer({ canvas: canvasRef.current, antialias: true });
    renderer.setSize(800, 600);

    scene.add(new THREE.AmbientLight(0xffffff, 0.4));
    const pointLight1 = new THREE.PointLight(0xffd700, 1.5);
    pointLight1.position.set(10, 10, 10);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x4444ff, 1.0);
    pointLight2.position.set(-10, -10, 5);
    scene.add(pointLight2);

    const group = new THREE.Group();
    const sequence = getSequence();
    for (let helix = 0; helix < harmony; helix++) {
      const helixGroup = new THREE.Group();
      const angleOffset = (helix * Math.PI * 2) / harmony;
      for (let i = 0; i < sequence.length; i++) {
        const digit = sequence[i];
        const t = i / 10;
        const radius = 3 + (digit / 10) * 2;
        const angle = angleOffset + t * Math.PI * 0.5;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        const z = t - 10;

        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(0.15 + digit * 0.02, 16, 16),
          new THREE.MeshPhongMaterial({
            color: new THREE.Color(digitToColor(digit)),
            emissive: new THREE.Color(digitToColor(digit)),
            emissiveIntensity: 0.5,
            shininess: 100
          })
        );
        sphere.position.set(x, y, z);
        sphere.userData = { digit, index: i };
        helixGroup.add(sphere);
      }
      group.add(helixGroup);
    }
    scene.add(group);

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const onMouseMove = (event: MouseEvent) => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const hit = raycaster.intersectObjects(scene.children, true)[0]?.object;
      if (hit?.userData?.digit !== undefined) {
        hit.material.emissiveIntensity = 1.0;
        if (audioInitialized) playChord([hit.userData.digit]);
        setTimeout(() => {
          if (hit.material) hit.material.emissiveIntensity = 0.5;
        }, 200);
      }
    };

    canvasRef.current.addEventListener('mousemove', onMouseMove);

    let animationId = 0;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      group.rotation.y += 0.003;
      group.rotation.x = Math.sin(Date.now() * 0.0003) * 0.1;
      const breathe = Math.sin(Date.now() * 0.001) * 0.1 + 1.0;
      group.scale.set(breathe, breathe, breathe);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationId);
      canvasRef.current?.removeEventListener('mousemove', onMouseMove);
      renderer.dispose();
    };
  }, [activeMode, audioInitialized, harmony, librariesReady, selectedSeed]);

  useEffect(() => {
    if (!particleCanvasRef.current || (activeMode !== 'mandala' && activeMode !== 'particles')) return;
    const canvas = particleCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const width = (canvas.width = 800);
    const height = (canvas.height = 800);
    const centerX = width / 2;
    const centerY = height / 2;

    const sequence = getSequence();
    if (activeMode === 'particles') {
      particlesRef.current = sequence.map((digit) => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        digit,
        color: digitToColor(digit),
        size: 2 + digit * 0.5
      }));
    }

    const onMouseDown = () => {
      mouseRef.current.down = true;
    };
    const onMouseUp = () => {
      mouseRef.current.down = false;
    };
    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      mouseRef.current.x = x;
      mouseRef.current.y = y;
      if (activeMode === 'mandala' && mouseRef.current.down) {
        setPaintedPattern((prev) => [...prev, { x, y }]);
        const dist = Math.sqrt((x - centerX) ** 2 + (y - centerY) ** 2);
        const digit = Math.floor((dist / 50) % 10);
        if (audioInitialized) playChord([digit]);
      }
    };

    canvas.addEventListener('mousemove', onMouseMove);
    if (activeMode === 'mandala') {
      canvas.addEventListener('mousedown', onMouseDown);
      canvas.addEventListener('mouseup', onMouseUp);
    }

    let animationId = 0;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      if (activeMode === 'mandala') {
        ctx.fillStyle = '#0a0e27';
        ctx.fillRect(0, 0, width, height);
        const segments = harmony * 12;
        for (let ring = 0; ring < 7; ring++) {
          const radius = (ring + 1) * 50;
          for (let i = 0; i < segments; i++) {
            const angle = (i / segments) * Math.PI * 2 - Math.PI / 2;
            const digit = sequence[(ring * segments + i) % sequence.length];
            const x = centerX + Math.cos(angle) * radius;
            const y = centerY + Math.sin(angle) * radius;
            ctx.beginPath();
            ctx.arc(x, y, 3 + digit * 0.5, 0, Math.PI * 2);
            ctx.fillStyle = digitToColor(digit);
            ctx.fill();
          }
        }

        paintedPattern.forEach((point) => {
          ctx.beginPath();
          ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 215, 0, 0.6)';
          ctx.fill();
        });
      } else if (activeMode === 'particles') {
        ctx.fillStyle = 'rgba(10, 14, 39, 0.1)';
        ctx.fillRect(0, 0, width, height);
        particlesRef.current.forEach((p) => {
          const dx = mouseRef.current.x - p.x;
          const dy = mouseRef.current.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > 0 && dist < 200) {
            const force = (200 - dist) / 1000;
            p.vx += (dx / dist) * force * (consciousness / 50);
            p.vy += (dy / dist) * force * (consciousness / 50);
          }
          p.x = Math.max(0, Math.min(width, p.x + p.vx));
          p.y = Math.max(0, Math.min(height, p.y + p.vy));
          p.vx *= 0.99;
          p.vy *= 0.99;
          if (p.x === 0 || p.x === width) p.vx *= -1;
          if (p.y === 0 || p.y === height) p.vy *= -1;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.fill();
        });
      }
    };
    animate();

    return () => {
      cancelAnimationFrame(animationId);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mousedown', onMouseDown);
      canvas.removeEventListener('mouseup', onMouseUp);
    };
  }, [activeMode, audioInitialized, consciousness, harmony, paintedPattern, selectedSeed]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 text-amber-50">
      <div className="relative z-10 mx-auto max-w-7xl p-6">
        <div className="mb-12 text-center">
          <h1 className="mb-4 bg-gradient-to-r from-amber-400 via-amber-200 to-amber-400 bg-clip-text text-6xl font-bold text-transparent">✨ Digital DNA ✨</h1>
          <p className="text-2xl font-light text-blue-300">Sacred Geometry & Sonic Consciousness</p>
          {!librariesReady && <p className="mt-3 text-sm text-amber-400">Loading 3D and audio libraries…</p>}
        </div>

        <div className="mb-12 flex justify-center gap-4">
          {[
            { id: 'spiral', icon: '🌀', label: 'DNA Helix' },
            { id: 'mandala', icon: '🔮', label: 'Sacred Mandala' },
            { id: 'particles', icon: '✨', label: 'Particle Field' },
            { id: 'sound', icon: '🎵', label: 'Sound Temple' },
            { id: 'journey', icon: '🧭', label: 'Guided Journey' }
          ].map((mode) => (
            <button key={mode.id} onClick={() => setActiveMode(mode.id as any)} className={`rounded-2xl px-6 py-4 ${activeMode === mode.id ? 'bg-amber-600' : 'bg-slate-800/50'}`}>
              <div className="text-3xl">{mode.icon}</div>
              <div className="text-sm font-bold">{mode.label}</div>
            </button>
          ))}
        </div>

        {activeMode === 'spiral' && <div className="flex justify-center"><canvas ref={canvasRef} className="rounded-xl border border-blue-700/30" /></div>}
        {(activeMode === 'mandala' || activeMode === 'particles') && <div className="flex justify-center"><canvas ref={particleCanvasRef} className="rounded-xl border border-purple-700/30" /></div>}

        {activeMode === 'sound' && (
          <div className="text-center">
            <button onClick={playSequence} disabled={isPlaying || !librariesReady} className="rounded-xl bg-pink-600 px-6 py-3 font-bold">
              {isPlaying ? '🎵 Playing...' : '▶️ Play DNA Sequence'}
            </button>
          </div>
        )}

        {activeMode === 'journey' && (
          <div className="mx-auto max-w-3xl rounded-2xl border border-slate-700/50 bg-slate-800/50 p-6">
            <p className="mb-4 text-lg text-amber-300">Tune your journey settings and jump into a mode:</p>
            <div className="mb-4 flex items-center gap-3">
              <span>Tempo:</span>
              <input type="range" min="60" max="180" value={tempo} onChange={(e) => setTempo(parseInt(e.target.value))} className="w-full" />
              <span>{tempo}</span>
            </div>
            <div className="mb-4 flex items-center gap-3">
              <span>Consciousness:</span>
              <input type="range" min="0" max="100" value={consciousness} onChange={(e) => setConsciousness(parseInt(e.target.value))} className="w-full" />
              <span>{consciousness}%</span>
            </div>
            <div className="flex gap-2">
              {[3, 5, 7, 9, 12].map((num) => (
                <button key={num} onClick={() => setHarmony(num)} className={`rounded-full px-4 py-2 ${harmony === num ? 'bg-purple-600' : 'bg-slate-700'}`}>{num}</button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-10 flex justify-center gap-3">
          {Object.keys(SEEDS).map((seed) => (
            <button key={seed} onClick={() => setSelectedSeed(seed as 'red' | 'black' | 'blue')} className={`rounded-full px-4 py-2 ${selectedSeed === seed ? 'bg-amber-500' : 'bg-slate-700'}`}>
              {seed}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DigitalDNAHub;
