import { cn } from '@/lib/utils';
import { getCopyrightNotice } from '@/lib/brand';

type LegalNoticeProps = {
  className?: string;
};

export function LegalNotice({ className }: LegalNoticeProps) {
  return <p className={cn('text-xs text-slate-400/90', className)}>{getCopyrightNotice()}</p>;
}
