'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Link2, Gift, Star, PawPrint, Sparkles, UsersRound, Dna, Gamepad2 } from 'lucide-react';

const TEACHER_NAV_ITEMS = [
  { href: '/', label: 'Hub', icon: Home },
  { href: '/pair', label: 'Pair', icon: Link2 },
  { href: '/forge', label: 'Forge', icon: Gift },
  { href: '/dna-hub', label: 'DNA', icon: Dna },
  { href: '/games', label: 'Games', icon: Gamepad2 },
  { href: '/constellation', label: 'Stars', icon: Star },
  { href: '/pet', label: 'Pet', icon: PawPrint },
] as const;

const KID_NAV_ITEMS = [
  { href: '/kid', label: 'Kid Hub', icon: Home },
  { href: '/kid/pair', label: 'Pair', icon: Link2 },
  { href: '/kid/redeem', label: 'Redeem', icon: Sparkles },
  { href: '/kid/bonds', label: 'Bonds', icon: UsersRound },
] as const;

export function VeilNav() {
  const pathname = usePathname();
  const isKidRoute = pathname === '/kid' || pathname.startsWith('/kid/');
  const navItems = isKidRoute ? KID_NAV_ITEMS : TEACHER_NAV_ITEMS;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pointer-events-none">
      <div className="mx-auto max-w-lg">
        <nav className="pointer-events-auto flex items-center justify-around rounded-2xl border border-slate-700/70 bg-slate-950/90 px-2 py-2 shadow-lg shadow-slate-950/60 backdrop-blur-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`
                  flex flex-col items-center justify-center gap-0.5
                  h-12 min-w-[52px] rounded-xl px-2
                  transition-all duration-200 touch-manipulation
                  ${isActive
                    ? 'bg-purple-500/20 text-purple-300'
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-white active:scale-95'
                  }
                `}
              >
                <Icon className="h-5 w-5" />
                <span
                  className={`text-[9px] font-medium ${
                    isActive ? 'opacity-100' : 'opacity-70'
                  }`}
                >
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>

        <div className="mt-2 flex justify-center">
          {isKidRoute ? (
            <Link
              href="/?as=teacher"
              className="pointer-events-auto rounded-full border border-cyan-500/40 bg-slate-950/80 px-3 py-1 text-[10px] text-cyan-300 transition hover:bg-cyan-500/10"
            >
              Switch to teacher routes
            </Link>
          ) : (
            <Link
              href="/kid?as=kid"
              className="pointer-events-auto rounded-full border border-purple-500/40 bg-slate-950/80 px-3 py-1 text-[10px] text-purple-200 transition hover:bg-purple-500/10"
            >
              Switch to kid routes
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
