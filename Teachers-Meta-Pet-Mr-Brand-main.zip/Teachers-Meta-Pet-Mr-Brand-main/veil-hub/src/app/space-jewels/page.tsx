import { redirect } from 'next/navigation';

export default function SpaceJewelsRedirectPage() {
  redirect('/school-quest');
}
