'use client';

import DigitalDNAHub from '@/components/veil/DigitalDNAHub';

export default function DigitalDNAPage() {
  return <DigitalDNAHub />;
}
