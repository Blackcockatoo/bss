#!/usr/bin/env node

import { spawnSync } from 'node:child_process';

const steps = [
  { name: 'Audit documentation checks', cmd: 'npm', args: ['run', 'check:audit-docs'] },
  { name: 'Audit scope lint', cmd: 'npm', args: ['run', 'lint:audit'] },
  { name: 'Helper duplicate lint', cmd: 'npm', args: ['--prefix', 'veil-hub', 'run', 'lint:helpers'] },
  { name: 'Test suite', cmd: 'npm', args: ['--prefix', 'veil-hub', 'run', 'test:suite'] },
  { name: 'Production build', cmd: 'npm', args: ['--prefix', 'veil-hub', 'run', 'build'] },
];

for (const [index, step] of steps.entries()) {
  console.log(`\n[${index + 1}/${steps.length}] ${step.name}`);
  const result = spawnSync(step.cmd, step.args, { stdio: 'inherit', shell: false });

  if (result.status !== 0) {
    console.error(`\nStep failed: ${step.name}`);
    process.exit(result.status ?? 1);
  }
}

console.log('\nFull update checks completed successfully.');
