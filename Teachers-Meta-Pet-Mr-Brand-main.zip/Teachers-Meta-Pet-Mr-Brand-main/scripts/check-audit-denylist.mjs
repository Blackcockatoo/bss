#!/usr/bin/env node
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = process.cwd();
const docsDir = join(root, 'docs');
const denylistPath = join(docsDir, 'audit-denylist.txt');
const scopePath = join(docsDir, 'audit-scope.md');
const args = new Set(process.argv.slice(2));
const checkScope = args.has('--check-scope') || args.has('--fail-unknown-identifiers');
const failUnknownIdentifiers = args.has('--fail-unknown-identifiers');

function loadDenylist(filePath) {
  const lines = readFileSync(filePath, 'utf8').split(/\r?\n/);
  return lines
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !line.startsWith('#'));
}

function collectAuditReports(dir) {
  const files = [];
  for (const entry of readdirSync(dir)) {
    const fullPath = join(dir, entry);
    const stats = statSync(fullPath);

    if (stats.isDirectory()) {
      files.push(...collectAuditReports(fullPath));
      continue;
    }

    const isMarkdown = entry.toLowerCase().endsWith('.md');
    const isAuditReport = /^audit-report.*\.md$/i.test(entry) && !/^audit-report-checklist\.md$/i.test(entry);

    if (isMarkdown && isAuditReport) {
      files.push(fullPath);
    }
  }

  return files;
}

function findMatches(content, pattern) {
  const regex = new RegExp(pattern, 'gi');
  const matches = [];
  let match;
  while ((match = regex.exec(content)) !== null) {
    matches.push({ value: match[0], index: match.index });
  }
  return matches;
}

function normalizeIdentifier(value) {
  return value.trim().toLowerCase();
}

function parseAllowedIdentifiers(scopeContent) {
  const appNames = new Set();
  const hosts = new Set();
  const lines = scopeContent.split(/\r?\n/);
  let section = '';

  for (const line of lines) {
    const heading = line.match(/^###\s+(.*)$/);
    if (heading) {
      section = heading[1].trim().toLowerCase();
      continue;
    }

    const bullet = line.match(/^[-*]\s+(.*)$/);
    if (!bullet) {
      continue;
    }

    const raw = bullet[1];
    const inlineCodeMatches = [...raw.matchAll(/`([^`]+)`/g)].map((match) => match[1]);
    const candidates = inlineCodeMatches.length > 0 ? inlineCodeMatches : [raw];

    for (const candidate of candidates) {
      const normalized = normalizeIdentifier(candidate.replace(/^\*\*|\*\*$/g, ''));
      if (normalized.length === 0) {
        continue;
      }

      if (section.includes('app name')) {
        appNames.add(normalized);
      }

      if (section.includes('host')) {
        hosts.add(normalized);
      }
    }
  }

  return { appNames, hosts };
}

function extractReportIdentifiers(content) {
  const appNames = new Set();
  const hosts = new Set();

  for (const match of content.matchAll(/^(?:[-*]\s*)?(?:app(?:lication)?|product|repo(?:sitory)?)\s*name\s*:\s*`?([a-z0-9._-]+)`?\s*$/gim)) {
    appNames.add(normalizeIdentifier(match[1]));
  }

  for (const match of content.matchAll(/`([a-z0-9]+(?:-[a-z0-9]+)+)`/gi)) {
    appNames.add(normalizeIdentifier(match[1]));
  }

  for (const match of content.matchAll(/https?:\/\/([a-z0-9.-]+(?::\d+)?)/gi)) {
    hosts.add(normalizeIdentifier(match[1]));
  }

  for (const match of content.matchAll(/^(?:[-*]\s*)?host\s*:\s*`?([a-z0-9.-]+(?::\d+)?)`?\s*$/gim)) {
    hosts.add(normalizeIdentifier(match[1]));
  }


  return { appNames, hosts };
}

const denylist = loadDenylist(denylistPath);
const auditReports = collectAuditReports(docsDir);

if (auditReports.length === 0) {
  console.log('No docs/audit-report*.md files found; denylist check skipped.');
  process.exit(0);
}

let hasViolations = false;
for (const reportPath of auditReports) {
  const content = readFileSync(reportPath, 'utf8');
  for (const pattern of denylist) {
    const matches = findMatches(content, pattern);
    if (matches.length > 0) {
      hasViolations = true;
      console.error(
        `Forbidden identifier pattern "${pattern}" found ${matches.length} time(s) in ${relative(root, reportPath)}.`,
      );
    }
  }
}

if (checkScope) {
  const scopeContent = readFileSync(scopePath, 'utf8');
  const allowed = parseAllowedIdentifiers(scopeContent);
  const unknownApps = [];
  const unknownHosts = [];

  for (const reportPath of auditReports) {
    const content = readFileSync(reportPath, 'utf8');
    const found = extractReportIdentifiers(content);

    for (const appName of found.appNames) {
      if (!allowed.appNames.has(appName)) {
        unknownApps.push({ appName, reportPath: relative(root, reportPath) });
      }
    }

    for (const host of found.hosts) {
      if (!allowed.hosts.has(host)) {
        unknownHosts.push({ host, reportPath: relative(root, reportPath) });
      }
    }
  }

  if (unknownApps.length > 0 || unknownHosts.length > 0) {
    const log = failUnknownIdentifiers ? console.error : console.warn;

    for (const { appName, reportPath } of unknownApps) {
      log(`Unknown app name "${appName}" found in ${reportPath}. Add it to docs/audit-scope.md if valid.`);
    }

    for (const { host, reportPath } of unknownHosts) {
      log(`Unknown host "${host}" found in ${reportPath}. Add it to docs/audit-scope.md if valid.`);
    }

    if (failUnknownIdentifiers) {
      hasViolations = true;
    }
  }
}

if (hasViolations) {
  process.exit(1);
}

console.log('Audit denylist check passed.');
if (checkScope) {
  console.log(
    failUnknownIdentifiers
      ? 'Audit scope identifier check passed (strict mode).'
      : 'Audit scope identifier check completed (warn-only mode).',
  );
}
