
import type { AddonTemplate } from './catalog';

// Starting ID for custom addons
let currentAddonId = 1008;

const generateAddonId = () => {
  return `custom-addon-${currentAddonId++}`;
};

export const CUSTOM_ADDONS: AddonTemplate[] = [
  {
    id: generateAddonId(),
    name: 'Quantum Entanglement Scarf',
    description: 'A scarf woven from entangled particles, allowing for instantaneous visual shifts and probabilistic color changes. Visually, it shimmers with impossible geometries and occasionally phases out of existence.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'body',
      offset: { x: 0, y: 10, z: 5 },
      scale: 1.1,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 20 50 Q 35 30 50 50 T 80 50 L 85 60 Q 65 80 50 60 T 15 60 Z
      `,
      colors: {
        primary: '#8A2BE2', // Blue Violet
        secondary: '#FF69B4', // Hot Pink
        accent: '#00FFFF', // Cyan
        glow: 'rgba(138, 43, 226, 0.7)',
      },
      animation: {
        type: 'shimmer',
        duration: 1500,
        easing: 'ease-in-out',
      },
      particles: {
        count: 15,
        color: '#FFFFFF',
        size: 2,
        behavior: 'burst',
      },
    },
    modifiers: {
      luck: 25,
      curiosity: 20,
    },
    metadata: {
      creator: 'Quantum Weavers Guild',
      tags: ['quantum', 'scarf', 'entanglement', 'mythic'],
      maxEditions: 5,
    },
  },
  {
    id: generateAddonId(),
    name: 'Gravity Well Gauntlet',
    description: 'A gauntlet that subtly manipulates local gravity, causing nearby objects (and the wearer) to experience minor, unpredictable shifts in weight and trajectory. Visually, it emanates a faint, swirling distortion field.',
    category: 'weapon',
    rarity: 'legendary',
    attachment: {
      anchorPoint: 'right-hand',
      offset: { x: 10, y: 0, z: 0 },
      scale: 1.0,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 30 70 L 20 50 L 30 30 L 70 30 L 80 50 L 70 70 Z
        M 50 40 A 10 10 0 1 1 50 60 A 10 10 0 1 1 50 40
      `,
      colors: {
        primary: '#4F4F4F', // Dark Grey
        secondary: '#A9A9A9', // Dark Gray
        accent: '#000000', // Black
        glow: 'rgba(79, 79, 79, 0.5)',
      },
      animation: {
        type: 'pulse',
        duration: 1000,
        easing: 'ease-in-out',
      },
      particles: {
        count: 10,
        color: '#36454F', // Charcoal
        size: 3,
        behavior: 'orbit',
      },
    },
    modifiers: {
      energy: 15,
      bond: 10,
    },
    metadata: {
      creator: 'Aether Forgers',
      tags: ['gravity', 'gauntlet', 'weapon', 'legendary'],
      maxEditions: 15,
    },
  },
  {
    id: generateAddonId(),
    name: 'Chrono-Shift Goggles',
    description: 'These goggles allow glimpses into alternate timelines, causing the wearer to occasionally appear slightly desynchronized with reality, flickering in and out of existence. Visually, they project faint, rapidly changing temporal distortions.',
    category: 'headwear',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'head',
      offset: { x: 0, y: -10, z: 10 },
      scale: 0.9,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 30 40 A 20 20 0 1 1 70 40 A 20 20 0 1 1 30 40 Z
        M 35 40 A 5 5 0 1 1 45 40 A 5 5 0 1 1 35 40 Z
        M 55 40 A 5 5 0 1 1 65 40 A 5 5 0 1 1 55 40 Z
      `,
      colors: {
        primary: '#1E90FF', // Dodger Blue
        secondary: '#8A2BE2', // Blue Violet
        accent: '#FFD700', // Gold
        glow: 'rgba(30, 144, 255, 0.6)',
      },
      animation: {
        type: 'sparkle',
        duration: 800,
        easing: 'linear',
      },
      particles: {
        count: 20,
        color: '#ADD8E6', // Light Blue
        size: 1,
        behavior: 'burst',
      },
    },
    modifiers: {
      curiosity: 30,
      luck: 10,
    },
    metadata: {
      creator: 'Temporal Cartographers',
      tags: ['time', 'goggles', 'chrono', 'mythic'],
      maxEditions: 7,
    },
  },
  {
    id: generateAddonId(),
    name: 'Echoing Void Orb',
    description: 'A small orb that absorbs ambient sound and occasionally emits distorted, ghostly echoes from forgotten places. Visually, it appears as a swirling vortex of deep purples and blacks.',
    category: 'companion',
    rarity: 'epic',
    attachment: {
      anchorPoint: 'floating',
      offset: { x: -20, y: 20, z: 0 },
      scale: 0.4,
      rotation: 0,
      followAnimation: false,
    },
    visual: {
      svgPath: `
        M 50 50 A 30 30 0 1 1 50 50 Z
        M 40 40 Q 50 30 60 40 Q 50 60 40 40 Z
      `,
      colors: {
        primary: '#191970', // Midnight Blue
        secondary: '#4B0082', // Indigo
        accent: '#800080', // Purple
        glow: 'rgba(25, 25, 112, 0.7)',
      },
      animation: {
        type: 'pulse',
        duration: 2000,
        easing: 'ease-in-out',
      },
      particles: {
        count: 10,
        color: '#DDA0DD', // Plum
        size: 2,
        behavior: 'ambient',
      },
    },
    modifiers: {
      bond: 15,
      energy: 10,
    },
    metadata: {
      creator: 'Void Whisperers',
      tags: ['void', 'orb', 'companion', 'epic'],
      maxEditions: 50,
    },
  },
  {
    id: generateAddonId(),
    name: 'Reality Anchor Pin',
    description: 'A small, unassuming pin that subtly reinforces the wearer\'s presence in reality, making them immune to minor temporal or spatial distortions. Visually, it emits a faint, steady glow that counteracts other visual anomalies.',
    category: 'accessory',
    rarity: 'legendary',
    attachment: {
      anchorPoint: 'body',
      offset: { x: 15, y: -15, z: 0 },
      scale: 0.7,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 20 L 60 40 L 40 40 Z
        M 50 40 L 60 60 L 40 60 Z
        M 50 60 L 60 80 L 40 80 Z
      `,
      colors: {
        primary: '#FFD700', // Gold
        secondary: '#DAA520', // Goldenrod
        accent: '#FFFFFF', // White
        glow: 'rgba(255, 215, 0, 0.8)',
      },
      animation: {
        type: 'glow',
        duration: 1000,
        easing: 'linear',
      },
      particles: {
        count: 5,
        color: '#FFFFFF',
        size: 1,
        behavior: 'ambient',
      },
    },
    modifiers: {
      energy: 20,
      luck: 15,
    },
    metadata: {
      creator: 'Aether Forgers',
      tags: ['reality', 'anchor', 'pin', 'legendary'],
      maxEditions: 20,
    },
  },
  {
    id: generateAddonId(),
    name: 'Dream Weaver Circlet',
    description: 'A delicate circlet that taps into the collective unconscious, occasionally manifesting dream-like illusions around the wearer. Visually, it projects soft, shifting patterns of light and shadow.',
    category: 'headwear',
    rarity: 'epic',
    attachment: {
      anchorPoint: 'head',
      offset: { x: 0, y: -5, z: 0 },
      scale: 1.0,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 20 50 A 30 30 0 1 1 80 50 A 30 30 0 1 1 20 50 Z
        M 30 50 A 20 20 0 1 1 70 50 A 20 20 0 1 1 30 50 Z
      `,
      colors: {
        primary: '#9370DB', // Medium Purple
        secondary: '#BA55D3', // Medium Orchid
        accent: '#FFC0CB', // Pink
        glow: 'rgba(147, 112, 219, 0.6)',
      },
      animation: {
        type: 'shimmer',
        duration: 2500,
        easing: 'ease-in-out',
      },
      particles: {
        count: 12,
        color: '#F0F8FF', // Alice Blue
        size: 1.5,
        behavior: 'ambient',
      },
    },
    modifiers: {
      curiosity: 18,
      bond: 12,
    },
    metadata: {
      creator: 'Oneiric Artisans',
      tags: ['dream', 'circlet', 'illusion', 'epic'],
      maxEditions: 40,
    },
  },
  {
    id: generateAddonId(),
    name: 'Temporal Loop Charm',
    description: 'A small charm that occasionally causes minor, localized time loops, making small actions repeat for a fraction of a second. Visually, it emits tiny, rapidly rewinding visual effects.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'body',
      offset: { x: -10, y: 10, z: 0 },
      scale: 0.6,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 20 A 30 30 0 1 0 50 80 A 30 30 0 0 0 50 20 Z
        M 50 30 L 70 50 L 50 70 L 30 50 Z
      `,
      colors: {
        primary: '#4682B4', // Steel Blue
        secondary: '#B0C4DE', // Light Steel Blue
        accent: '#FF4500', // Orange Red
        glow: 'rgba(70, 130, 180, 0.7)',
      },
      animation: {
        type: 'rotate',
        duration: 500,
        easing: 'linear',
      },
      particles: {
        count: 8,
        color: '#FFD700', // Gold
        size: 1,
        behavior: 'burst',
      },
    },
    modifiers: {
      luck: 20,
      energy: 15,
    },
    metadata: {
      creator: 'Chronosmiths',
      tags: ['time', 'loop', 'charm', 'mythic'],
      maxEditions: 8,
    },
  },
  {
    id: generateAddonId(),
    name: 'Aetheric Blade',
    description: 'A blade forged from pure aether, it phases in and out of physical reality, making its strikes unpredictable and visually stunning. It leaves shimmering trails of displaced energy.',
    category: 'weapon',
    rarity: 'legendary',
    attachment: {
      anchorPoint: 'right-hand',
      offset: { x: 20, y: -5, z: 0 },
      scale: 1.3,
      rotation: -45,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 20 80 L 30 20 L 70 20 L 80 80 Z
        M 45 25 L 55 25 L 50 15 Z
      `,
      colors: {
        primary: '#00CED1', // Dark Turquoise
        secondary: '#40E0D0', // Turquoise
        accent: '#FFFFFF', // White
        glow: 'rgba(0, 206, 209, 0.6)',
      },
      animation: {
        type: 'shimmer',
        duration: 1200,
        easing: 'ease-in-out',
      },
      particles: {
        count: 18,
        color: '#E0FFFF', // Light Cyan
        size: 2,
        behavior: 'trail',
      },
    },
    modifiers: {
      energy: 22,
      curiosity: 10,
    },
    metadata: {
      creator: 'Celestial Armory',
      tags: ['aether', 'blade', 'weapon', 'legendary'],
      maxEditions: 18,
    },
  },
  {
    id: generateAddonId(),
    name: 'Illusionist\'s Veil',
    description: 'A veil that distorts perception, making the wearer appear as a constantly shifting, indistinct figure. It projects subtle, mesmerizing optical illusions.',
    category: 'headwear',
    rarity: 'epic',
    attachment: {
      anchorPoint: 'head',
      offset: { x: 0, y: 0, z: 0 },
      scale: 1.0,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 10 50 Q 30 20 50 50 Q 70 80 90 50 Q 70 20 50 50 Q 30 80 10 50 Z
      `,
      colors: {
        primary: '#800080', // Purple
        secondary: '#FF00FF', // Magenta
        accent: '#FFFF00', // Yellow
        glow: 'rgba(128, 0, 128, 0.5)',
      },
      animation: {
        type: 'pulse',
        duration: 1800,
        easing: 'ease-in-out',
      },
      particles: {
        count: 15,
        color: '#FFC0CB', // Pink
        size: 1.5,
        behavior: 'ambient',
      },
    },
    modifiers: {
      curiosity: 15,
      bond: 10,
    },
    metadata: {
      creator: 'Mirage Weavers',
      tags: ['illusion', 'veil', 'headwear', 'epic'],
      maxEditions: 35,
    },
  },
  {
    id: generateAddonId(),
    name: 'Starlight Mantle',
    description: 'A cloak woven from captured starlight, it twinkles with distant constellations and occasionally projects miniature nebulae. The wearer leaves faint trails of cosmic dust.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'back',
      offset: { x: 0, y: 5, z: -10 },
      scale: 1.4,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 20 20 Q 50 0 80 20 L 85 80 Q 50 100 15 80 Z
      `,
      colors: {
        primary: '#191970', // Midnight Blue
        secondary: '#4B0082', // Indigo
        accent: '#FFFFFF', // White
        glow: 'rgba(25, 25, 112, 0.8)',
      },
      animation: {
        type: 'sparkle',
        duration: 2000,
        easing: 'linear',
      },
      particles: {
        count: 25,
        color: '#FFD700', // Gold
        size: 1,
        behavior: 'ambient',
      },
    },
    modifiers: {
      luck: 28,
      energy: 20,
    },
    metadata: {
      creator: 'Cosmic Tailors',
      tags: ['starlight', 'mantle', 'cosmic', 'mythic'],
      maxEditions: 6,
    },
  },
  {
    id: generateAddonId(),
    name: 'Resonance Amplifier',
    description: 'A device that amplifies the wearer\'s emotional resonance, causing their moods to manifest as visible, swirling auras of color and energy. Behaviorally, it can subtly influence the emotions of those nearby.',
    category: 'effect',
    rarity: 'legendary',
    attachment: {
      anchorPoint: 'aura',
      offset: { x: 0, y: 0, z: 0 },
      scale: 1.6,
      rotation: 0,
      followAnimation: false,
    },
    visual: {
      svgPath: `
        M 50 10 A 40 40 0 1 1 50 90 A 40 40 0 1 1 50 10 Z
        M 50 20 A 30 30 0 1 1 50 80 A 30 30 0 1 1 50 20 Z
      `,
      colors: {
        primary: '#FF4500', // Orange Red
        secondary: '#FFD700', // Gold
        accent: '#ADFF2F', // Green Yellow
        glow: 'rgba(255, 69, 0, 0.7)',
      },
      animation: {
        type: 'pulse',
        duration: 1000,
        easing: 'ease-in-out',
      },
      particles: {
        count: 20,
        color: '#FFFFFF',
        size: 2,
        behavior: 'ambient',
      },
    },
    modifiers: {
      bond: 25,
      curiosity: 15,
    },
    metadata: {
      creator: 'Emotional Engineers',
      tags: ['resonance', 'amplifier', 'aura', 'legendary'],
      maxEditions: 12,
    },
  },
  {
    id: generateAddonId(),
    name: 'Void Step Boots',
    description: 'Boots that allow the wearer to briefly step into a pocket dimension, appearing to teleport short distances. Visually, they leave behind faint, dissolving afterimages.',
    category: 'accessory',
rarity: 'mythic',
    attachment: {
      anchorPoint: 'body',
      offset: { x: 0, y: -30, z: 0 },
      scale: 1.0,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 30 70 L 20 60 L 20 80 L 30 90 L 70 90 L 80 80 L 80 60 L 70 70 Z
      `,
      colors: {
        primary: '#2F4F4F', // Dark Slate Gray
        secondary: '#696969', // Dim Gray
        accent: '#000000', // Black
        glow: 'rgba(47, 79, 79, 0.6)',
      },
      animation: {
        type: 'shimmer',
        duration: 800,
        easing: 'ease-in-out',
      },
      particles: {
        count: 10,
        color: '#D3D3D3', // Light Gray
        size: 1.5,
        behavior: 'trail',
      },
    },
    modifiers: {
      energy: 20,
      luck: 10,
    },
    metadata: {
      creator: 'Dimensional Wayfarers',
      tags: ['void', 'boots', 'teleport', 'mythic'],
      maxEditions: 9,
    },
  },
  {
    id: generateAddonId(),
    name: 'Reality Bending Ring',
    description: 'A ring that subtly warps local reality, causing minor visual distortions and occasional improbable events in the wearer\'s vicinity. Visually, it emanates a faint, shimmering heat haze.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'right-hand',
      offset: { x: 5, y: 5, z: 0 },
      scale: 0.5,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 50 A 20 20 0 1 1 50 50 Z
        M 45 45 L 55 45 L 55 55 L 45 55 Z
      `,
      colors: {
        primary: '#FF8C00', // Dark Orange
        secondary: '#FFA500', // Orange
        accent: '#FFFFFF', // White
        glow: 'rgba(255, 140, 0, 0.7)',
      },
      animation: {
        type: 'pulse',
        duration: 1200,
        easing: 'ease-in-out',
      },
      particles: {
        count: 7,
        color: '#FFDAB9', // Peach Puff
        size: 1,
        behavior: 'ambient',
      },
    },
    modifiers: {
      luck: 30,
      curiosity: 20,
    },
    metadata: {
      creator: 'Reality Shapers',
      tags: ['reality', 'bending', 'ring', 'mythic'],
      maxEditions: 4,
    },
  },
];

  {
    id: generateAddonId(),
    name: 'Chronal Compass',
    description: 'A compass that points not to magnetic north, but to significant temporal anomalies. Its needle spins wildly when near paradoxes, and it occasionally projects faint echoes of past or future events. Visually, the compass face shimmers with temporal distortions.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'body',
      offset: { x: -10, y: -10, z: 5 },
      scale: 0.8,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 50 A 30 30 0 1 1 50 50 Z
        M 50 20 L 55 30 L 45 30 Z
        M 50 80 L 55 70 L 45 70 Z
        M 20 50 L 30 55 L 30 45 Z
        M 80 50 L 70 55 L 70 45 Z
      `,
      colors: {
        primary: '#A9A9A9', // Dark Gray
        secondary: '#696969', // Dim Gray
        accent: '#FFD700', // Gold
        glow: 'rgba(169, 169, 169, 0.6)',
      },
      animation: {
        type: 'rotate',
        duration: 3000,
        easing: 'linear',
      },
      particles: {
        count: 10,
        color: '#ADD8E6', // Light Blue
        size: 1.5,
        behavior: 'ambient',
      },
    },
    modifiers: {
      curiosity: 25,
      luck: 18,
    },
    metadata: {
      creator: 'Temporal Cartographers',
      tags: ['time', 'compass', 'chronal', 'mythic'],
      maxEditions: 7,
    },
  },
];

  {
    id: generateAddonId(),
    name: 'Reality Anchor Pin',
    description: 'A small, unassuming pin that subtly reinforces the wearer\'s presence in reality, making them immune to minor temporal or spatial distortions. Visually, it emits a faint, steady glow that counteracts other visual anomalies.',
    category: 'accessory',
    rarity: 'legendary',
    attachment: {
      anchorPoint: 'body',
      offset: { x: 15, y: -15, z: 0 },
      scale: 0.7,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 20 L 60 40 L 40 40 Z
        M 50 40 L 60 60 L 40 60 Z
        M 50 60 L 60 80 L 40 80 Z
      `,
      colors: {
        primary: '#FFD700', // Gold
        secondary: '#DAA520', // Goldenrod
        accent: '#FFFFFF', // White
        glow: 'rgba(255, 215, 0, 0.8)',
      },
      animation: {
        type: 'glow',
        duration: 1000,
        easing: 'linear',
      },
      particles: {
        count: 5,
        color: '#FFFFFF',
        size: 1,
        behavior: 'ambient',
      },
    },
    modifiers: {
      energy: 20,
      luck: 15,
    },
    metadata: {
      creator: 'Aether Forgers',
      tags: ['reality', 'anchor', 'pin', 'legendary'],
      maxEditions: 20,
    },
  },
];

  {
    id: generateAddonId(),
    name: 'Dimensional Shard Brooch',
    description: 'A brooch containing a fragment of a fractured dimension, causing localized gravitational anomalies and visual distortions around the wearer. It occasionally pulls in tiny, harmless objects from other realities.',
    category: 'accessory',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'body',
      offset: { x: 0, y: 0, z: 10 },
      scale: 0.9,
      rotation: 0,
      followAnimation: true,
    },
    visual: {
      svgPath: `
        M 50 10 L 70 30 L 50 50 L 30 30 Z
        M 50 50 L 70 70 L 50 90 L 30 70 Z
        M 30 30 L 10 50 L 30 70
        M 70 30 L 90 50 L 70 70
      `,
      colors: {
        primary: '#8B008B', // Dark Magenta
        secondary: '#FF00FF', // Magenta
        accent: '#00FFFF', // Cyan
        glow: 'rgba(139, 0, 139, 0.7)',
      },
      animation: {
        type: 'shimmer',
        duration: 1800,
        easing: 'ease-in-out',
      },
      particles: {
        count: 15,
        color: '#E0FFFF', // Light Cyan
        size: 1.5,
        behavior: 'burst',
      },
    },
    modifiers: {
      luck: 22,
      curiosity: 18,
    },
    metadata: {
      creator: 'Interdimensional Jewelers',
      tags: ['dimensional', 'brooch', 'shard', 'mythic'],
      maxEditions: 6,
    },
  },
];

  {
    id: generateAddonId(),
    name: 'Aura of Sentience',
    description: 'An aura that grants the wearer a heightened sense of awareness, occasionally revealing hidden truths or precognitive flashes. Visually, it manifests as subtle, shimmering glyphs and symbols that appear and disappear around the wearer.',
    category: 'aura',
    rarity: 'mythic',
    attachment: {
      anchorPoint: 'aura',
      offset: { x: 0, y: 0, z: 0 },
      scale: 1.7,
      rotation: 0,
      followAnimation: false,
    },
    visual: {
      svgPath: `
        M 50 10 A 40 40 0 1 1 50 90 A 40 40 0 1 1 50 10 Z
        M 30 40 L 40 30 L 50 40 L 60 30 L 70 40
        M 30 60 L 40 70 L 50 60 L 60 70 L 70 60
      `,
      colors: {
        primary: '#FFD700', // Gold
        secondary: '#ADFF2F', // Green Yellow
        accent: '#00FFFF', // Cyan
        glow: 'rgba(255, 215, 0, 0.8)',
      },
      animation: {
        type: 'shimmer',
        duration: 2000,
        easing: 'ease-in-out',
      },
      particles: {
        count: 20,
        color: '#FFFFFF',
        size: 1.5,
        behavior: 'ambient',
      },
    },
    modifiers: {
      curiosity: 30,
      energy: 20,
    },
    metadata: {
      creator: 'Ethereal Scribes',
      tags: ['aura', 'sentience', 'precognition', 'mythic'],
      maxEditions: 5,
    },
  },
];
